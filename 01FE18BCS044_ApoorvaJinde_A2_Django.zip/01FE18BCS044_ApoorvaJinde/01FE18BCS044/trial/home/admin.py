from django.contrib import admin
from home.models import Contact
from home.models import Student

# Register your models here.
admin.site.register(Contact)
admin.site.register(Student)

