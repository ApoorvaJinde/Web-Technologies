from django.http import request
from django.shortcuts import render, HttpResponse
from datetime import datetime
from home.models import Contact
from home.models import Student
# Create your views here.
def index(request):
    return render(request,'index.html')
    #return HttpResponse("This is a home page")
def display(request):
    c_list=Student.objects.all()
    g1=Student.objects.filter(grade__contains='1')
    g2=Student.objects.filter(grade__contains='2')
    g3=Student.objects.filter(grade__contains='3')
    g4=Student.objects.filter(grade__contains='4')
    g5=Student.objects.filter(grade__contains='5')
    g6=Student.objects.filter(grade__contains='6')
    g7=Student.objects.filter(grade__contains='7')
    g8=Student.objects.filter(grade__contains='8')
    g9=Student.objects.filter(grade__contains='9')
    g10=Student.objects.filter(grade__contains='10')
    g11=Student.objects.filter(grade__contains='11')
    g12=Student.objects.filter(grade__contains='12')



    return render(request,'display.html', {'g1': g1,'g2':g2,'g3':g3,'g4':g4,'g5':g5,'g6':g6,'g7':g7,'g8':g8,'g9':g9,'g10':g10,'g11':g11,'g12':g12})
def search(request):
    if request.method=="POST":
         searched=request.POST['searched']
         contacts=Contact.objects.filter(name__contains=searched)
    return render(request,'search.html',{'searched':searched,'contacts':contacts})

def contact(request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        desc=request.POST.get('desc')
        contact=Contact(name=name,email=email,phone=phone,desc=desc,date=datetime.today())
        contact.save()
    return render(request,'contact.html')
def addmission(request):
    if request.method=="POST":
        name=request.POST.get('name')
        age=request.POST.get('age')
        grade=request.POST.get('grade')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        students=Student(name=name,age=age,grade=grade,email=email,phone=phone,date=datetime.today())
        students.save()
    return render(request,'contact.html')

