var http = require("http");
var mysql = require('mysql');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
const { json } = require("body-parser");

var urlencodedParser = bodyParser.urlencoded({ extended: true });
//---------------------------------------------//
   var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "UserData"
});

//-------------------------------------------//
app.get('/send', function (req, res) {

res.sendFile(__dirname + '/index.html');

  
})

app.post('/user', urlencodedParser, function (req, res) {

    res.sendFile(__dirname + '/user.html');
    
      
})


app.post('/searchjob', urlencodedParser, function (req, res) {

    res.sendFile(__dirname + '/searchjob.html');
    
      
})

app.post('/admin', urlencodedParser, function (req, res) {

    res.sendFile(__dirname + '/admin.html');
    
      
})

app.post('/registration', urlencodedParser, function (req, res){
  
  var reply='';
  
  name = req.body.one;
  age=req.body.two;
  qualification=req.body.three;
  specialization=req.body.four;
  domain = req.body.five;
  role=req.body.six;
  location=req.body.seven;

  var sql =" insert into user(name,age,qualification,specialization,domain, role,location) values('"+name+"',"+age+",'"+qualification+"','"+specialization+"','"+domain+"','"+ role+"', '"+ location+"')";
 //----------------------------------------------------------------------------------//
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});
con.query(sql, function (err, result) {
 if (err) throw err; 
  res.write("rec inserted");
 });

//------------------------------------------------------------------------------------//
 res.write("Record Inserted");
  res.end();
 })

 app.post('/search', urlencodedParser, function (req, res){
  
    var reply='';
    
    role= req.body.one;
    
    location=req.body.two;
    
    var sql =" SELECT * user where role='"+role+"' and location='"+location+"'";
  con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
  });
  con.query(sql, function (err, result) {
   if (err) throw err; 
    res.write("rec inserted");
    console.log(result);
   });
  
  //------------------------------------------------------------------------------------//
   res.write(sql);
    res.end();
   })

app.post('/delete',urlencodedParser,  function (req, res){
  
  var reply='';
  role = req.body.del;
  age = req.body.del1;
   var sql ="DELETE FROM users WHERE age ="+age+" ";

  con.connect(function(err) {
      if (err) throw err;
      console.log("Connected!");
    });
  con.query(sql , function (err, result) {
      if (err) throw err;
      console.log(result);
    });
    
    
    res.write("Record Deleted");
    res.end();
})
app.listen(9000, function () {
    console.log('Connected to port 9000');
});